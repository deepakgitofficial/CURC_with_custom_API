import React from 'react'

const Home = () => {
  return (
    <div>
        <div className=''>
            <h1>Home Page</h1>
            
        </div>
    </div>
  )
}

export default Home